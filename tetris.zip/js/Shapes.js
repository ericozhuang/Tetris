//专门定义每个格子数据结构的类型
function Cell(r,c,img){
	this.r = r;
	this.c = c;
	this.img = img;
}
//专门定义所有图形的公共类型
function Shape(cells,states,orgi){
	this.cells = cells;//保存图形对象中所有格子对象
	this.states = states;//保存图形对象的不同状态对象
	this.orgi = orgi;//保存当前图形参照格子的下标
	this.statei = 0;
}
//在Shape类型的原型中，集中定义所有图形共有的数据和方法
//专门保存每种图形的格子，使用的图片路径
Shape.prototype.IMGS = {
		I:"img/I.png",
		O:"img/O.png",
		T:"img/T.png",
		J:"img/J.png",
		L:"img/L.png",
		S:"img/S.png",
		Z:"img/Z.png"
};
Shape.prototype.moveDown = function(){//当前图形下落一格
	//遍历当前图形的每个格子
	for (var i=0;i<this.cells.length;i++){
		this.cells[i].r+=1;//	将每个格的r+=1
	}
};
Shape.prototype.moveLeft = function(){//当前图形左移一格
	//遍历当前图形的每个格子
	for (var i=0;i<this.cells.length;i++){
		this.cells[i].c-=1;//	将每个格的c-=1
	}
};
Shape.prototype.moveRight = function(){//当前图形右移一格
	//遍历当前图形的每个格子
	for (var i=0;i<this.cells.length;i++){
		this.cells[i].c+=1;//	将每个格的c+=1
	}	
};
Shape.prototype.rotateR = function(){//shape.rotateR()
	//this->shape
	//将shape的statei+1
	this.statei+=1;
	//如果statei>shape的states的长度-1，就让statei回0
	this.statei>this.states.length-1&&(this.statei=0);
	this.rotate();
}
Shape.prototype.rotateL = function(){//shape.rotateL()
	//this->shape
	//将shape的statei-1
	this.statei-=1;
	//如果statei<0，就让statei回shape的states的长度-1
	this.statei<0&&(this.statei=this.states.length-1);
	this.rotate();
}
Shape.prototype.rotate = function(){
	//获得参照格对象：cells[orgi]，保存在cell中
	var cell = this.cells[this.orgi];
	//获得新状态对象：states[statei]，保存在state中
	var state = this.states[this.statei];
	//遍历cells中所有格子对象
	for(var i=0;i<this.cells.length;i++){
	//	当前格的r=cell.r+state["r"+i]
		this.cells[i].r = cell.r+state["r"+i]
	//	当前格的c=cell.c+state.["c"+i]
		this.cells[i].c = cell.c+state["c"+i]
	}
}
//定义状态对象结构，描述所有状态
function State(r0,c0,r1,c1,r2,c2,r3,c3){
	this.r0 = r0;this.r1 = r1;
	this.c0 = c0;this.c1 = c1;
	this.r2 = r2;this.r3 = r3;
	this.c2 = c2;this.c3 = c3;	
}

//创建具体图形类型,继承Shape类型结构以及原型对象
function T(){//专门描述所拥有T型图形的数据结构
	Shape.call(this,[//this-->正在创建的新对象
		new Cell(0,3,this.IMGS.T),//应为T类型继承了Shape
		new Cell(0,4,this.IMGS.T),
		new Cell(0,5,this.IMGS.T),
		new Cell(1,4,this.IMGS.T)
	],[
		new State(0,-1,0,0,0,1,1,0),
		new State(-1,0,0,0,1,0,0,-1),
		new State(0,1,0,0,0,-1,-1,0),
		new State(1,0,0,0,-1,0,0,1),
	],1);
}
Object.setPrototypeOf(T.prototype,Shape.prototype);

function O(){//专门描述所拥有O型图形的数据结构
	Shape.call(this,[
		new Cell(0,4,this.IMGS.O),
		new Cell(0,5,this.IMGS.O),
		new Cell(1,4,this.IMGS.O),
		new Cell(1,5,this.IMGS.O)
	],[
		new State(0,0,0,1,1,0,1,1)
	],0);
}
Object.setPrototypeOf(O.prototype,Shape.prototype);

function I(){//专门描述所拥有I型图形的数据结构
	Shape.call(this,[
		new Cell(0,3,this.IMGS.I),
		new Cell(0,4,this.IMGS.I),
		new Cell(0,5,this.IMGS.I),
		new Cell(0,6,this.IMGS.I)
	],[
		new State(0,-1,0,0,0,1,0,2),
		new State(-1,0,0,0,1,0,2,0)
	],1);
}
Object.setPrototypeOf(I.prototype,Shape.prototype);

////专门描述所拥有J型图形的数据结构
function J(){
	Shape.call(this,[
		new Cell(0,3,this.IMGS.J),
		new Cell(0,4,this.IMGS.J),
		new Cell(0,5,this.IMGS.J),
		new Cell(1,5,this.IMGS.J),
	],[
		new State(0,-1,0,0,0,1,1,1),
		new State(-1,0,0,0,1,0,1,-1),
		new State(0,1,0,0,0,-1,-1,-1),
		new State(1,0,0,0,-1,0,-1,1)
	],1)
}
Object.setPrototypeOf(J.prototype,Shape.prototype);
////专门描述所拥有L型图形的数据结构
function L(){
	Shape.call(this,[
		new Cell(0,3,this.IMGS.L),
		new Cell(0,4,this.IMGS.L),
		new Cell(0,5,this.IMGS.L),
		new Cell(1,3,this.IMGS.L)
	],[
		new State(0,-1,0,0,0,1,1,-1),
		new State(-1,0,0,0,1,0,-1,-1),
		new State(0,1,0,0,0,-1,-1,1),
		new State(1,0,0,0,-1,0,1,1)
	],1)
}
Object.setPrototypeOf(L.prototype,Shape.prototype);
////专门描述所拥有S型图形的数据结构
function S(){
	Shape.call(this,[
		new Cell(0,4,this.IMGS.S),
		new Cell(0,5,this.IMGS.S),
		new Cell(1,3,this.IMGS.S),
		new Cell(1,4,this.IMGS.S)
	],[
		new State(-1,0,-1,1,0,-1,0,0),
		new State(0,1,1,1,-1,0,0,0)
	],3)
}
Object.setPrototypeOf(S.prototype,Shape.prototype);
////专门描述所拥有Z型图形的数据结构
function Z(){
	Shape.call(this,[
		new Cell(0,3,this.IMGS.Z),
		new Cell(0,4,this.IMGS.Z),
		new Cell(1,4,this.IMGS.Z),
		new Cell(1,5,this.IMGS.Z)
	],[
		new State(-1,-1,-1,0,0,0,0,1),
		new State(-1,1,0,1,0,0,1,0)
	],2)
}
Object.setPrototypeOf(Z.prototype,Shape.prototype);